# Basel Trader Mobile

Mobile-first PWA dashboard for a US momentum paper-trading bot.

## Architecture
- iPhone / Android: dashboard only.
- Cloud server: scanner, strategy, risk manager, execution, database.
- Broker: modular adapter; Alpaca Paper in v1.
- The bot continues running on the server even if the phone is locked or offline.

## Run locally for testing
```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
uvicorn app.main:app --host 0.0.0.0 --port 8000
```

## Cloud deployment
The repository includes a Dockerfile. Deploy it to any Docker-compatible cloud host.
Add the environment variables from `.env.example` in the host dashboard.

## Install on iPhone
After deployment:
1. Open the HTTPS URL in Safari.
2. Share.
3. Add to Home Screen.
4. Basel Trader opens full-screen like an app.

## Safety
Paper only by default. `ENABLE_PAPER_ORDERS=false` prevents execution until explicitly enabled.
